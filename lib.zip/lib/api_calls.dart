import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uniform_swap_admin/apis.dart';
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';


class ApiService {
  // ================= CONSTANTS =================

  static const String _tokenKey = "token";
  static const String _userIdKey = "user_id";

  // ================= AUTH STORAGE =================

  static Future<void> saveAuthData({required String token, required String userId,}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_userIdKey, userId);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  static Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userIdKey);
  }

  static Future<void> clearAuth() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userIdKey);
  }

  // ================= HEADERS =================

  static Future<Map<String, String>> _headers() async {
    final token = await getToken();
    print('token in header $token');
    return {
      "Content-Type": "application/json",
      "Accept": "application/json",
      if (token != null && token.isNotEmpty)
        "Authorization": 'Bearer $token',
    };
  }

  // ================= API METHODS =================

  static Future<dynamic> get(String endpoint) async {
    final response = await http.get(
      Uri.parse("$baseUrl$endpoint"),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  static Future<dynamic> post(
      String endpoint,
      Map<String, dynamic> body,
      ) async
  {
    print("POST ${baseUrl+endpoint}   ");

    final response = await http.post(
      Uri.parse("$baseUrl$endpoint"),
      headers: await _headers(),
      body: jsonEncode(body),
    );
    print('object');
    print("POST ${baseUrl+endpoint} ${response.statusCode}   body ${response.body}");
    return _handleResponse(response);
  }

  static Future<dynamic> put(
      String endpoint, {
        Map<String, dynamic>? body,
      }) async {
    final response = await http.put(
      Uri.parse("$baseUrl$endpoint"),
      headers: await _headers(),
      body: body != null ? jsonEncode(body) : null,
    );

    return _handleResponse(response);
  }


  static Future<dynamic> delete(String endpoint) async {
    final response = await http.delete(
      Uri.parse("$baseUrl$endpoint"),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  // ================= MULTIPART POST =================
  static Future<dynamic> postMultipart(
      String endpoint, {
        required Map<String, String> fields,
        required List<http.MultipartFile> files,
      }) async
  {
    final uri = Uri.parse("$baseUrl$endpoint");
    final request = http.MultipartRequest("POST", uri);

    request.fields.addAll(fields);
    request.files.addAll(files);

    final token = await getToken();
    print('tokens #############$token');
    request.headers.addAll({
      "Accept": "application/json",
      if (token != null && token.isNotEmpty)
        "Authorization": token,
    });

    // DEBUG FILE INFO
    for (final f in files) {
      debugPrint(
        "Uploading → ${f.field} | ${f.filename} | ${f.contentType}",
      );
    }

    final streamedResponse = await request.send();
    final responseBody =
    await streamedResponse.stream.bytesToString();

    debugPrint(
      "MULTIPART ${streamedResponse.statusCode} → $responseBody",
    );

    if (streamedResponse.statusCode >= 200 &&
        streamedResponse.statusCode < 300) {
      return jsonDecode(responseBody);
    } else {
      throw Exception(
        "API Error ${streamedResponse.statusCode}: $responseBody",
      );
    }
  }
  static Future<dynamic> patch(String endpoint,
      {Map<String, dynamic>? body}) async {
    final response = await http.patch(
      Uri.parse('$baseUrl$endpoint'),
      headers:  await _headers(),
      body: jsonEncode(body),
    );
    print(response.body);
    print(response.request);

    return _handleResponse(response);
  }

  // ================= IMAGE MULTIPART HELPER =================
  static Future<http.MultipartFile> imageFile(
      String field,
      String path,
      ) async
  {
    final mimeType = lookupMimeType(path);

    if (mimeType == null || !mimeType.startsWith('image/')) {
      throw Exception("Invalid image file: $path");
    }

    return http.MultipartFile.fromPath(
      field,
      path,
      contentType: MediaType.parse(mimeType),
    );
  }



  // ================= RESPONSE HANDLER =================

  static dynamic _handleResponse(http.Response response) async {

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return jsonDecode(response.body);
    }

    if (response.statusCode == 401) {
      await clearAuth();
      throw Exception("Unauthorized / Session expired");
    }


  }

}
