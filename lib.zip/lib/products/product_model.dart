enum ProductStatus {
  pending,
  approved,
  rejected,
  sold,
}

class ProductModel {
  final String id;
  final String name;
  final String sellerName;
  final String sellerEmail;
  final String category;
  final String description;
  final double price;
  final List<String> images;
  final int stockQuantity;
  final String submittedAt;
  ProductStatus status;

  ProductModel({
    required this.id,
    required this.name,
    required this.sellerName,
    required this.sellerEmail,
    required this.category,
    required this.description,
    required this.price,
    required this.images,
    required this.stockQuantity,
    required this.submittedAt,
    required this.status,
  });

  static double _parseDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  static int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  factory ProductModel.fromJson(Map<String, dynamic> json) {
    return ProductModel(
      id: json['id']?.toString() ?? "",
      name: json['title'] ?? "",
      sellerName: json['user']?['name'] ?? "",
      sellerEmail: json['user']?['email'] ?? "",
      category: json['category'] ?? "",
      description: json['description'] ?? "",
      price: _parseDouble(json['price']),
      images: (json['images'] is List)
          ? (json['images'] as List)
          .where((e) => e is String && e.isNotEmpty)
          .map((e) => e.toString())
          .toList()
          : [],
      stockQuantity: _parseInt(json['quantity']),
      submittedAt: json['created_at'] ?? "",
      status: json['is_sold'] == true
          ? ProductStatus.sold
          : json['is_approved'] == true
          ? ProductStatus.approved
          : ProductStatus.pending,
    );
  }
}
