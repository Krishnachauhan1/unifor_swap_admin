import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:uniform_swap_admin/app_colors.dart';
import 'package:uniform_swap_admin/products/product_controller.dart';
import 'package:uniform_swap_admin/products/product_model.dart';
import 'package:uniform_swap_admin/user/user_screen.dart';
import 'package:uniform_swap_admin/widget/filter_chip_bar.dart';
import 'package:uniform_swap_admin/products/product_card.dart';
import 'package:uniform_swap_admin/widget/search_bar_widget.dart';
import 'package:uniform_swap_admin/widget/status_card.dart';
import 'product_detail_view.dart';

class ProductListView extends StatelessWidget {
  const ProductListView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ProductController());
    final bool isWide = MediaQuery.of(context).size.width > 900;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.onPrimary,
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.admin_panel_settings,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Uniform Saler Admin',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Product Approval Panel',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white70,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // Users button
          IconButton(
            icon: const Icon(Icons.people_outline_rounded),
            tooltip: 'Users',
            onPressed: () {

              Get.to(() => UserScreen()); // if using direct navigation
            },
          ),
          Obx(
                () => controller.isLoading.value
                ? const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              ),
            )
                : IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Refresh',
              onPressed: controller.refreshProducts,
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: AppColors.primary),
                SizedBox(height: 16),
                Text(
                  'Loading products...',
                  style: TextStyle(color: AppColors.textSecondary),
                ),
              ],
            ),
          );
        }
        return Column(
          children: [
            // Stats Row
            Container(
              color: AppColors.primary,
              child: Container(
                decoration: const BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 4),
                  child: isWide
                      ? Row(
                    children: [
                      Expanded(
                        child: StatsCard(
                          label: 'Total',
                          count: controller.totalCount,
                          color: AppColors.secondary,
                          icon: Icons.inventory_2_outlined,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatsCard(
                          label: 'Pending',
                          count: controller.pendingCount,
                          color: AppColors.warning,
                          icon: Icons.pending_outlined,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatsCard(
                          label: 'Approved',
                          count: controller.approvedCount,
                          color: AppColors.success,
                          icon: Icons.check_circle_outline,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatsCard(
                          label: 'Rejected',
                          count: controller.rejectedCount,
                          color: AppColors.error,
                          icon: Icons.cancel_outlined,
                        ),
                      ),
                    ],
                  )
                      : GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 2.8,
                    children: [
                      StatsCard(
                        label: 'Total',
                        count: controller.totalCount,
                        color: AppColors.secondary,
                        icon: Icons.inventory_2_outlined,
                      ),
                      StatsCard(
                        label: 'Pending',
                        count: controller.pendingCount,
                        color: AppColors.warning,
                        icon: Icons.pending_outlined,
                      ),
                      StatsCard(
                        label: 'Approved',
                        count: controller.approvedCount,
                        color: AppColors.success,
                        icon: Icons.check_circle_outline,
                      ),
                      StatsCard(
                        label: 'Rejected',
                        count: controller.rejectedCount,
                        color: AppColors.error,
                        icon: Icons.cancel_outlined,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Search & Filters
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: SearchBarWidget(onChanged: controller.setSearch),
            ),
            const SizedBox(height: 12),
            FilterChipBar(
              selected: controller.selectedFilter.value,
              onSelected: controller.setFilter,
              counts: {
                FilterOption.all: controller.totalCount,
                FilterOption.pending: controller.pendingCount,
                FilterOption.approved: controller.approvedCount,
                FilterOption.rejected: controller.rejectedCount,
              },
            ),
            const SizedBox(height: 12),
            // Product Grid
            Expanded(
              child: controller.filteredProducts.isEmpty
                  ? _buildEmpty()
                  : isWide
                  ? _buildWideGrid(controller)
                  : _buildNarrowList(controller),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildWideGrid(ProductController controller) {
    final products = controller.filteredProducts;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GridView.builder(
        padding: const EdgeInsets.only(bottom: 24, top: 4),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 320,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.62,
        ),
        itemCount: products.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.all(8.0),
          child: ProductCard(
            product: products[i],
            onTap: () => _openDetail(products[i], controller),
            onApprove: () => controller.approveProduct(products[i].id),
            onReject: () => controller.rejectProduct(products[i].id),
          ),
        ),
      ),
    );
  }

  Widget _buildNarrowList(ProductController controller) {
    final products = controller.filteredProducts;
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
      itemCount: products.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (ctx, i) => Padding(
        padding: const EdgeInsets.all(8.0),
        child: ProductCard(
          product: products[i],
          onTap: () => _openDetail(products[i], controller),
          onApprove: () => controller.approveProduct(products[i].id),
          onReject: () => controller.rejectProduct(products[i].id),
          isListMode: true,
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inbox_outlined, size: 64, color: AppColors.textHint),
          const SizedBox(height: 16),
          const Text(
            'No products found',
            style: TextStyle(
              fontSize: 18,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Try changing your filters or search term',
            style: TextStyle(fontSize: 14, color: AppColors.textHint),
          ),
        ],
      ),
    );
  }

  void _openDetail(ProductModel product, ProductController controller) {
    final isWide = Get.width > 900;
    if (isWide) {
      Get.dialog(
        Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 60,
            vertical: 40,
          ),
          child: SizedBox(
            width: 800,
            height: Get.height * 0.88,
            child: ProductDetailView(
              product: product,
              onApprove: () {
                controller.approveProduct(product.id);
                Get.back();
              },
              onReject: () {
                controller.rejectProduct(product.id);
                Get.back();
              },
            ),
          ),
        ),
        barrierColor: Colors.black54,
      );
    } else {
      Get.to(
            () => Scaffold(
          body: ProductDetailView(
            product: product,
            onApprove: () {
              controller.approveProduct(product.id);

              Future.delayed(const Duration(milliseconds: 120), () {
                if (Get.isOverlaysOpen) {
                  Navigator.of(Get.context!, rootNavigator: true).pop();
                }
              });
            },
            onReject: () {
              controller.rejectProduct(product.id);

              Future.delayed(const Duration(milliseconds: 120), () {
                if (Get.isOverlaysOpen) {
                  Navigator.of(Get.context!, rootNavigator: true).pop();
                }
              });
            },
          ),
        ),
      );
    }
  }
}