import 'package:flutter/material.dart';
import 'package:uniform_swap_admin/apis.dart';
import 'package:uniform_swap_admin/app_colors.dart';
import 'package:uniform_swap_admin/products/product_model.dart';

class ProductCard extends StatefulWidget {
  final ProductModel product;
  final VoidCallback onTap;
  final VoidCallback onApprove;
  final VoidCallback onReject;
  final bool isListMode;

  const ProductCard({
    super.key,
    required this.product,
    required this.onTap,
    required this.onApprove,
    required this.onReject,
    this.isListMode = false,
  });

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _hoverController;
  late Animation<double> _elevationAnim;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    print(widget.product.images);
    _hoverController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _elevationAnim = Tween<double>(begin: 2, end: 8).animate(_hoverController);
  }

  @override
  void dispose() {
    _hoverController.dispose();
    super.dispose();
  }

  void _onHover(bool value) {
    setState(() => _isHovered = value);
    value ? _hoverController.forward() : _hoverController.reverse();
  }

  String _getImageUrl(String imagePath) {
    final cleanPath =
    imagePath.startsWith('/') ? imagePath.substring(1) : imagePath;

    final cleanBase =
    imageBaseUrl.endsWith('/') ? imageBaseUrl : '$imageBaseUrl/';

    print('image is ${'${cleanBase}storage/$cleanPath'}');
    // IMPORTANT: Add "storage/"
    return '${cleanBase}storage/$cleanPath';
  }


  Widget _buildProductImage({
    required double? width,
    required double? height,
  }) {
    if (widget.product.images.isEmpty) {
      return Container(
        width: width,
        height: height,
        color: const Color(0xFFF5F5F5),
        child: const Center(
          child: Icon(Icons.image_not_supported,
              size: 40, color: AppColors.textHint),
        ),
      );
    }

    final imageUrl = _getImageUrl(widget.product.images.first);

    return Image.network(
      imageUrl,
      width: width,
      height: height,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        width: width,
        height: height,
        color: const Color(0xFFF5F5F5),
        child: const Icon(Icons.checkroom,
            size: 40, color: AppColors.textHint),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: widget.isListMode ? _buildListCard() : _buildGridCard(),
    );
  }

  // ================= GRID CARD =================

  Widget _buildGridCard() {
    final product = widget.product;

    return MouseRegion(
      onEnter: (_) => _onHover(true),
      onExit: (_) => _onHover(false),
      child: AnimatedBuilder(
        animation: _elevationAnim,
        builder: (_, __) => Material(
          elevation: _elevationAnim.value,
          borderRadius: BorderRadius.circular(14),
          color: Colors.white,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: widget.onTap,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(14)),
                      child: AspectRatio(
                        aspectRatio: 1.1,
                        child: _buildProductImage(
                            width: double.infinity, height: null),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: _StatusChip(status: product.status),
                    ),
                  ],
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(product.category,
                            style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: AppColors.secondary)),
                        const SizedBox(height: 4),
                        Text(product.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text(product.sellerName,
                            style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.textHint)),
                        const Spacer(),
                        Text(
                          '₹${product.price.toStringAsFixed(0)}',
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primary),
                        ),
                        if (product.status == ProductStatus.pending) ...[
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: _ActionBtn(
                                  label: 'Reject',
                                  icon: Icons.close,
                                  color: AppColors.error,
                                  onTap: widget.onReject,
                                  isFilled: false,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: _ActionBtn(
                                  label: 'Approve',
                                  icon: Icons.check,
                                  color: AppColors.success!,
                                  onTap: widget.onApprove,
                                  isFilled: true,
                                ),
                              ),
                            ],
                          )
                        ]
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ================= LIST CARD =================

  Widget _buildListCard() {
    final product = widget.product;

    return MouseRegion(
      onEnter: (_) => _onHover(true),
      onExit: (_) => _onHover(false),
      child: AnimatedBuilder(
        animation: _elevationAnim,
        builder: (_, __) => Material(
          elevation: _elevationAnim.value,
          borderRadius: BorderRadius.circular(14),
          color: Colors.white,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: widget.onTap,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child:
                    _buildProductImage(width: 90, height: 90),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        Text(product.name,
                            style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(product.sellerName,
                            style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.textHint)),
                        const SizedBox(height: 6),
                        Text(
                          '₹${product.price.toStringAsFixed(0)}',
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primary),
                        ),
                      ],
                    ),
                  ),
                  _buildStatusIcon(product.status),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusIcon(ProductStatus status) {
    IconData icon;
    Color color;

    switch (status) {
      case ProductStatus.approved:
        icon = Icons.check_circle;
        color = AppColors.success!;
        break;
      case ProductStatus.rejected:
        icon = Icons.cancel;
        color = AppColors.error;
        break;
      case ProductStatus.sold:
        icon = Icons.shopping_bag;
        color = AppColors.primary;
        break;
      default:
        icon = Icons.schedule;
        color = AppColors.warning;
    }

    return Icon(icon, color: color, size: 28);
  }
}

// ================= STATUS CHIP =================

class _StatusChip extends StatelessWidget {
  final ProductStatus status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color bg, fg;
    String label;
    IconData icon;

    switch (status) {
      case ProductStatus.pending:
        bg = const Color(0xFFFFF3E0);
        fg = AppColors.warning;
        label = 'Pending';
        icon = Icons.schedule;
        break;
      case ProductStatus.approved:
        bg = const Color(0xFFE8F5E9);
        fg = AppColors.success!;
        label = 'Approved';
        icon = Icons.check_circle;
        break;
      case ProductStatus.rejected:
        bg = const Color(0xFFFFEBEE);
        fg = AppColors.error;
        label = 'Rejected';
        icon = Icons.cancel;
        break;
      case ProductStatus.sold:
        bg = const Color(0xFFE3F2FD);
        fg = AppColors.primary;
        label = 'Sold';
        icon = Icons.shopping_bag;
        break;
    }

    return Container(
      padding:
      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: fg),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  color: fg,
                  fontSize: 11,
                  fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

// ================= ACTION BUTTON =================

class _ActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final bool isFilled;

  const _ActionBtn({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
    required this.isFilled,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: isFilled
          ? ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 14),
        label:
        Text(label, style: const TextStyle(fontSize: 12)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
        ),
      )
          : OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 14),
        label:
        Text(label, style: const TextStyle(fontSize: 12)),
        style: OutlinedButton.styleFrom(
          foregroundColor: color,
          side: BorderSide(color: color),
        ),
      ),
    );
  }
}
