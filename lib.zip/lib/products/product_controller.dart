import 'package:get/get.dart';
import 'package:uniform_swap_admin/api_calls.dart';
import 'package:uniform_swap_admin/apis.dart';
import 'package:uniform_swap_admin/products/product_model.dart';

class ProductController extends GetxController {
  final RxList<ProductModel> _allProducts = <ProductModel>[].obs;
  final RxBool isLoading = false.obs;
  final Rx<FilterOption> selectedFilter = FilterOption.all.obs;
  final RxString searchQuery = ''.obs;

  List<ProductModel> get filteredProducts {
    List<ProductModel> result = _allProducts.toList();

    // Apply status filter
    if (selectedFilter.value == FilterOption.pending) {
      result = result.where((p) => p.status == ProductStatus.pending).toList();
    } else if (selectedFilter.value == FilterOption.approved) {
      result = result.where((p) => p.status == ProductStatus.approved).toList();
    } else if (selectedFilter.value == FilterOption.rejected) {
      result = result.where((p) => p.status == ProductStatus.rejected).toList();
    }

    // Apply search
    if (searchQuery.value.isNotEmpty) {
      final q = searchQuery.value.toLowerCase();

      result = result.where((p) {
        return p.name.toLowerCase().contains(q) ||
            p.sellerName.toLowerCase().contains(q) ||
            p.category.toLowerCase().contains(q);
      }).toList();
    }


    return result;
  }

  int get pendingCount =>
      _allProducts.where((p) => p.status == ProductStatus.pending).length;

  int get approvedCount =>
      _allProducts.where((p) => p.status == ProductStatus.approved).length;

  int get rejectedCount =>
      _allProducts.where((p) => p.status == ProductStatus.rejected).length;

  int get totalCount => _allProducts.length;

  @override
  void onInit() {
    super.onInit();
    _loadProducts();
  }

  // ================= LOAD PRODUCTS =================

  Future<void> _loadProducts() async {
    try {
      isLoading.value = true;

      final response = await ApiService.get(allItemsApi);

      List list = response['data'];
      print('products ========== ${list[0]}');
      _allProducts.assignAll(
        list.map((e) => ProductModel.fromJson(e)).toList(),
      );

      print("Products loaded: ${_allProducts[0].status}");
    } catch (e) {
      print(e);
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> refreshProducts() async {
    await _loadProducts();
  }

  // ================= APPROVE PRODUCT =================

  Future<void> approveProduct(String id) async {
    try {
      print('$baseUrl$uniformsApi/$id/approve');
      final res = await ApiService.patch(
        '$uniformsApi/$id/approve',
        body: {
          "is_approved": true,
        },

      );

      print("Approve Response: $res");
      _loadProducts();

    } catch (e) {

      print("Approve Error: $e");
    }
  }

  // ================= REJECT PRODUCT =================

  Future<void> rejectProduct(String id) async {
    // try {
    //   await ApiService.put(
    //     "$uniformsApi/$id/approve",
    //     {"is_approved": false},
    //   );
    //
    //   Get.snackbar("Rejected", "Product Rejected");
    //   await refreshProducts();
    // } catch (e) {
    //   Get.snackbar("Error", e.toString());
    // }
  }

  void setFilter(FilterOption filter) {
    selectedFilter.value = filter;
  }

  void setSearch(String query) {
    searchQuery.value = query;
  }
}

enum FilterOption { all, pending, approved, rejected }
