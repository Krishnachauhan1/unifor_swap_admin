import 'package:get/get.dart';
import 'package:uniform_swap_admin/api_calls.dart';
import 'package:uniform_swap_admin/apis.dart';
import 'package:uniform_swap_admin/user/user_model.dart';

class UserController extends GetxController {
  var isLoading = false.obs;
  var users = <UserModel>[].obs;
  var filteredUsers = <UserModel>[].obs;
  var searchQuery = ''.obs;
  var selectedRole = 'all'.obs;

  @override
  void onInit() {
    super.onInit();
    getUsers();
  }

  Future<void> getUsers() async {
    try {
      isLoading.value = true;
      final res = await ApiService.get(usersApi);

      if (res['success'] == true && res['data'] != null) {
        users.value = (res['data'] as List)
            .map((json) => UserModel.fromJson(json))
            .toList();
        applyFilters();
      }
    } catch (e) {
      print('Error fetching users: $e');
      Get.snackbar('Error', 'Failed to load users');
    } finally {
      isLoading.value = false;
    }
  }

  void setSearch(String query) {
    searchQuery.value = query.toLowerCase();
    applyFilters();
  }

  void setRoleFilter(String role) {
    selectedRole.value = role;
    applyFilters();
  }

  void applyFilters() {
    filteredUsers.value = users.where((user) {
      final matchesSearch = searchQuery.value.isEmpty ||
          user.name.toLowerCase().contains(searchQuery.value) ||
          user.email.toLowerCase().contains(searchQuery.value) ||
          user.phone.contains(searchQuery.value);

      final matchesRole = selectedRole.value == 'all' ||
          user.role == selectedRole.value;

      return matchesSearch && matchesRole;
    }).toList();
  }

  Future<void> toggleUserStatus(int userId, bool currentStatus) async {
    try {
      // Update API call here
      // await ApiService.post('users/$userId/toggle-status', {'is_active': !currentStatus});

      final index = users.indexWhere((u) => u.id == userId);
      if (index != -1) {
        users[index].isActive = !currentStatus;
        users.refresh();
        applyFilters();
        Get.snackbar('Success', 'User status updated');
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to update user status');
    }
  }

  int get totalUsers => users.length;
  int get activeUsers => users.where((u) => u.isActive).length;
  int get adminUsers => users.where((u) => u.role == 'admin').length;
  int get regularUsers => users.where((u) => u.role == 'user').length;
}