import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:uniform_swap_admin/app_theme.dart';
import 'package:uniform_swap_admin/authentication/auth/login_view.dart';

void main() {
  runApp(const UniformAdminApp());
}

class UniformAdminApp extends StatelessWidget {
  const UniformAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Uniform Saler Admin',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: LoginView(),
    );
  }
}
