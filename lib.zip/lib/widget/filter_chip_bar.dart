import 'package:flutter/material.dart';

import 'package:uniform_swap_admin/app_colors.dart';
import 'package:uniform_swap_admin/products/product_controller.dart';

class FilterChipBar extends StatelessWidget {
  final FilterOption selected;
  final Function(FilterOption) onSelected;
  final Map<FilterOption, int> counts;

  const FilterChipBar({
    super.key,
    required this.selected,
    required this.onSelected,
    required this.counts,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        children: [
          _FilterTab(
            label: 'All',
            count: counts[FilterOption.all] ?? 0,
            isSelected: selected == FilterOption.all,
            activeColor: AppColors.secondary,
            onTap: () => onSelected(FilterOption.all),
          ),
          const SizedBox(width: 8),
          _FilterTab(
            label: 'Pending',
            count: counts[FilterOption.pending] ?? 0,
            isSelected: selected == FilterOption.pending,
            activeColor: AppColors.warning,
            onTap: () => onSelected(FilterOption.pending),
          ),
          const SizedBox(width: 8),
          _FilterTab(
            label: 'Approved',
            count: counts[FilterOption.approved] ?? 0,
            isSelected: selected == FilterOption.approved,
            activeColor: AppColors.success,
            onTap: () => onSelected(FilterOption.approved),
          ),
          const SizedBox(width: 8),
          _FilterTab(
            label: 'Rejected',
            count: counts[FilterOption.rejected] ?? 0,
            isSelected: selected == FilterOption.rejected,
            activeColor: AppColors.error,
            onTap: () => onSelected(FilterOption.rejected),
          ),
        ],
      ),
    );
  }
}

class _FilterTab extends StatelessWidget {
  final String label;
  final int count;
  final bool isSelected;
  final Color activeColor;
  final VoidCallback onTap;

  const _FilterTab({
    required this.label,
    required this.count,
    required this.isSelected,
    required this.activeColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? activeColor : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected ? activeColor : const Color(0xFFDDDDDD),
            ),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: activeColor.withOpacity(0.25),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: isSelected ? Colors.white : const Color(0xFF757575),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.white.withOpacity(0.25)
                      : const Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '$count',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isSelected ? Colors.white : const Color(0xFF757575),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
