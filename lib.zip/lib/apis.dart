final baseUrl = 'https://uniformswap.nextlogicsolution.id/api/';
const String imageBaseUrl = "https://uniformswap.nextlogicsolution.id/";
final loginAPi = 'login';
final signupApi = 'login';
final schoolsApi = 'schools';
const String uniformsApi = "school-items";
const String allItemsApi = "admin/items";
const String usersApi = "users";
