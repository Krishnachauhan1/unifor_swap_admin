import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uniform_swap_admin/api_calls.dart';
import 'package:uniform_swap_admin/apis.dart';
import 'package:uniform_swap_admin/products/product_list_view.dart';

class AuthController extends GetxController {
  var isLoading = false.obs;

  final emailCtrl = TextEditingController(text: 'admin@admin.com');
  final passwordCtrl = TextEditingController(text: '123456');
  final nameCtrl = TextEditingController();
  Future<void> saveUserData(Map<String, dynamic> res) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString('token', res['token']);

    // Save user as JSON string
    await prefs.setString('user', jsonEncode(res['user']));


    update();
  }
  // LOGIN
  Future<String?> loginIn() async {
    try {
      // toggle loading

      final res = await ApiService.post(loginAPi, {
        "email": emailCtrl.text.trim(),
        "password": passwordCtrl.text.trim(),
      });

      print(res);

      if (res['success'] == true) {
        await saveUserData(res);
        Get.offAll(() => ProductListView());
        // Save token & user to SharedPreferences
      }

      return null;
    } catch (e) {
      return 'Login failed';
    } finally {}
  }
}
