import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:uniform_swap_admin/authentication/controllers/auth_controller.dart';
import '../../app_colors.dart';

class LoginView extends StatelessWidget {
  LoginView({super.key});

  final controller = Get.put(AuthController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          SizedBox.expand(
            child: Image.asset("assets/images/uniform.jpg", fit: BoxFit.cover),
          ),

          Container(color: Colors.black.withOpacity(0.5)),

          Center(
            child: Container(
              width: 400,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.95),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.admin_panel_settings,
                    size: 70,
                    color: AppColors.primary,
                  ),

                  const SizedBox(height: 20),

                  TextField(
                    controller: controller.emailCtrl,
                    decoration: const InputDecoration(labelText: "Email"),
                  ),

                  const SizedBox(height: 12),

                  TextField(
                    controller: controller.passwordCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: "Password"),
                  ),

                  const SizedBox(height: 20),

                  Obx(
                    () => controller.isLoading.value
                        ? const CircularProgressIndicator()
                        : ElevatedButton(
                            onPressed: controller.loginIn,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              minimumSize: const Size(double.infinity, 50),
                            ),
                            child: const Text("LOGIN"),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
